"""Invariants that decide whether the numbers mean anything.

Each of these guards a specific mistake that would make results better and
would not look like an error in any output.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
import torch

from mint.evaluate import (
    campaign_detection,
    daily_queue,
    queue_metrics,
    ranking_metrics,
)
from mint.model import apply_masking
from mint.schema import MASK_ID, PAD_ID
from mint.scoring import robust_z, self_distance
from mint.sessionise import token_for, typed_events
from mint.training import context_cardinalities


# -- sessionisation ---------------------------------------------------------
def test_the_day_boundary_is_four_am(fixture_dir):
    """An event at 02:00 belongs to the previous working day, not its own."""
    events = typed_events(fixture_dir, day_start_hour=4)
    small_hours = events[events["hour"] < 4]
    if small_hours.empty:
        pytest.skip("the fixture produced no events before 4am")
    row = small_hours.iloc[0]
    assert row["day"].date() == (row["ts"] - pd.Timedelta(hours=4)).date()
    assert row["day"] < row["ts"].normalize()


def test_empty_cc_fields_do_not_make_every_email_external():
    """The bug that made the internal class disappear entirely."""
    row = pd.Series({"from": "AAA0001@company.invalid", "user": "AAA0001",
                     "to": "AAA0002@company.invalid", "cc": np.nan,
                     "bcc": np.nan, "attachments": 0})
    assert token_for("email", row) == "email_send_internal"


def test_a_genuinely_external_recipient_is_detected():
    row = pd.Series({"from": "AAA0001@company.invalid", "user": "AAA0001",
                     "to": "someone@elsewhere.invalid", "cc": np.nan,
                     "bcc": np.nan, "attachments": 0})
    assert token_for("email", row) == "email_send_external"


def test_mail_from_someone_else_is_a_receipt():
    row = pd.Series({"from": "AAA0009@company.invalid", "user": "AAA0001",
                     "to": "AAA0001@company.invalid", "cc": "", "bcc": "",
                     "attachments": 0})
    assert token_for("email", row) == "email_receive"


def test_removable_media_writes_are_typed_separately():
    assert token_for("file", pd.Series({"filename": r"R:\\dump.zip"})) \
        == "file_copy_to_removable"
    assert token_for("file", pd.Series({"filename": r"C:\\work\\notes.docx"})) \
        == "file_open"


# -- splits and labels ------------------------------------------------------
def test_splits_are_chronological_and_disjoint(bundle):
    days = bundle.index.groupby("split")["day"].agg(["min", "max"])
    assert days.loc["train", "max"] < days.loc["calibrate", "min"]
    assert days.loc["calibrate", "max"] < days.loc["test", "min"]


def test_no_known_malicious_day_is_in_the_training_window(bundle):
    train = bundle.index[bundle.index["split"] == "train"]
    assert int(train["label"].sum()) == 0, (
        "a detector fitted on the campaign it is meant to find is not a detector"
    )


def test_labels_exist_at_all(bundle):
    assert bundle.n_labelled_malicious > 0


def test_campaign_day_is_never_negative(bundle):
    cd = bundle.index["campaign_day"].dropna()
    assert (cd >= 0).all()


# -- masking ----------------------------------------------------------------
def test_padding_is_never_masked():
    tokens = torch.tensor([[3, 4, 5, PAD_ID, PAD_ID], [3, PAD_ID, PAD_ID, PAD_ID, PAD_ID]])
    masked, selected = apply_masking(tokens, probability=0.9)
    assert not selected[tokens == PAD_ID].any()
    assert (masked[tokens == PAD_ID] == PAD_ID).all()


def test_every_non_empty_row_gets_at_least_one_target():
    tokens = torch.tensor([[3, 4, PAD_ID], [5, PAD_ID, PAD_ID]])
    _, selected = apply_masking(tokens, probability=0.0)
    assert selected.any(dim=1).all()


def test_masking_replaces_with_the_mask_token():
    tokens = torch.tensor([[3, 4, 5, 6]])
    masked, selected = apply_masking(tokens, probability=1.0)
    assert (masked[selected] == MASK_ID).all()


# -- scoring ----------------------------------------------------------------
def test_self_distance_only_looks_backwards():
    """A person's future must not influence how their present is scored.

    Constructed so the answer is unambiguous: one person, flat history, then a
    single enormous jump on the last day. If the baseline were computed over
    the whole record, the jump would drag the centre towards itself and score
    lower than it does here.
    """
    n = 12
    emb = np.zeros((n, 4), dtype=np.float32)
    emb[:, 0] = np.arange(n) * 0.01
    emb[-1, 0] = 50.0
    index = pd.DataFrame({
        "user": ["u"] * n,
        "day": pd.date_range("2010-01-01", periods=n, freq="D"),
    })
    d = self_distance(emb, index, history_days=30)
    assert d[0] == 0.0, "the first day has no history and must score zero"
    assert (d[:5] == 0).all(), "days before the minimum history must score zero"
    assert d[-1] == d.max()
    assert d[-1] > 10 * np.median(d[5:-1])


def test_self_distance_is_zero_before_any_history_exists():
    emb = np.random.default_rng(0).normal(size=(4, 3)).astype(np.float32)
    index = pd.DataFrame({"user": ["a", "b", "a", "b"],
                          "day": pd.to_datetime(["2010-01-01", "2010-01-01",
                                                 "2010-01-02", "2010-01-02"])})
    d = self_distance(emb, index, history_days=30)
    assert (d == 0).all()


def test_a_single_day_of_history_cannot_produce_an_infinite_score():
    """The bug the minimum-history floor exists to prevent.

    One person, two identical days, then a small deviation. Without the floor
    the within-person spread is zero and the third day scores in the
    thousands, which would push a genuine anomaly off the top of the queue.
    """
    emb = np.array([[0.0, 0.0], [0.0, 0.0], [0.01, 0.0],
                    [0.0, 0.0], [0.0, 0.0], [0.0, 0.0], [0.02, 0.0]],
                   dtype=np.float32)
    index = pd.DataFrame({"user": ["u"] * 7,
                          "day": pd.date_range("2010-01-01", periods=7)})
    d = self_distance(emb, index, history_days=30)
    assert np.isfinite(d).all()
    assert d.max() < 100


def test_robust_z_is_not_moved_by_a_few_extreme_values():
    base = np.concatenate([np.zeros(1000), np.full(5, 1e6)])
    z = robust_z(base)
    assert abs(np.median(z)) < 1e-9
    assert abs(z[:1000]).max() < 1.0


# -- evaluation -------------------------------------------------------------
def _toy_queue():
    return pd.DataFrame({
        "user": ["a", "b", "c", "a", "b", "c"],
        "day": pd.to_datetime(["2010-01-01"] * 3 + ["2010-01-02"] * 3),
        "label": [1, 0, 0, 0, 1, 0],
        "scenario": [1, 0, 0, 0, 1, 0],
        "campaign_day": [0, np.nan, np.nan, np.nan, 1, np.nan],
    })


def test_daily_queue_ranks_within_each_day():
    index = _toy_queue()
    scores = np.array([0.9, 0.5, 0.1, 0.2, 0.8, 0.3])
    q = daily_queue(index, scores, capacity=1)
    first_day = q[q["day"] == pd.Timestamp("2010-01-01")]
    assert first_day.iloc[0]["user"] == "a"
    assert int(q["alerted"].sum()) == 2      # one per day


def test_queue_metrics_by_hand():
    index = _toy_queue()
    scores = np.array([0.9, 0.5, 0.1, 0.2, 0.8, 0.3])
    q = daily_queue(index, scores, capacity=1)
    m = queue_metrics(q, capacity=1)
    # Two alerts raised, both of them the genuine insider day.
    assert m["alerts_raised"] == 2
    assert m["alerts_true"] == 2
    assert m["precision"] == 1.0
    assert m["recall_user_days"] == 1.0
    assert m["wasted_reviews_per_catch"] == 0.0


def test_capacity_of_one_never_alerts_twice_in_a_day():
    index = _toy_queue()
    scores = np.arange(6, dtype=float)
    q = daily_queue(index, scores, capacity=1)
    assert q.groupby("day")["alerted"].sum().max() == 1


def test_campaign_detection_reports_days_into_the_campaign():
    n = 5
    index = pd.DataFrame({
        "user": ["x"] * n,
        "day": pd.date_range("2010-02-01", periods=n, freq="D"),
        "label": [1] * n,
        "scenario": [2] * n,
        "campaign_day": list(range(n)),
    })
    # A decoy colleague on every day, so that ranking actually decides who is
    # alerted. Without them a capacity of one always alerts the only user
    # present, and the test would pass for the wrong reason.
    decoy = index.copy()
    decoy["user"] = "decoy"
    decoy[["label", "scenario"]] = 0
    decoy["campaign_day"] = np.nan
    index = pd.concat([index, decoy], ignore_index=True)

    # Only the third campaign day outscores the decoy.
    scores = np.array([0.1, 0.1, 9.0, 0.1, 0.1] + [1.0] * n)
    camp = campaign_detection(index, scores, capacity=1)
    assert len(camp) == 1
    assert bool(camp.iloc[0]["detected"])
    assert camp.iloc[0]["days_into_campaign"] == 2


def test_ranking_metrics_handle_a_window_with_no_positives():
    m = ranking_metrics(np.zeros(10), np.random.default_rng(0).normal(size=10))
    assert np.isnan(m["auroc"])


# -- model plumbing ---------------------------------------------------------
def test_context_cardinalities_cover_every_observed_level(bundle):
    cards = context_cardinalities(bundle)
    assert len(cards) == 5
    assert all(c >= 1 for c in cards)


def test_ablation_zeroes_the_intended_modality(bundle):
    from mint.pipeline import _ablate
    no_content = _ablate(bundle, "no_content")
    assert not no_content.content.any()
    assert no_content.tokens.any(), "behaviour must survive a content ablation"


# -- reading the release without unpacking it -------------------------------
def test_a_tarball_and_a_directory_give_identical_results(fixture_dir, cfg, tmp_path):
    """The disk-constrained path must not be a different pipeline.

    Extracted, r4.2 needs about 3 GB of free space and http.csv is 1.7 GB of
    it. Reading members straight out of the archive removes that requirement
    entirely, which is only worth having if it produces the same numbers.
    """
    import tarfile

    from mint.prepare import prepare
    from mint.sources import Release

    archive_dir = tmp_path / "packed"
    archive_dir.mkdir()
    with tarfile.open(archive_dir / "r4.2.tar.bz2", "w:bz2") as tf:
        tf.add(fixture_dir, arcname="r4.2")

    from_dir = prepare(fixture_dir, cfg, "hashing", synthetic=True)
    from_tar = prepare(Release(archive_dir), cfg, "hashing", synthetic=True)

    assert len(from_dir) == len(from_tar)
    assert (from_dir.tokens == from_tar.tokens).all()
    assert from_dir.n_labelled_malicious == from_tar.n_labelled_malicious


def test_a_release_can_be_a_bare_tarball(fixture_dir, tmp_path):
    import tarfile

    from mint.sources import Release

    path = tmp_path / "r4.2.tar.bz2"
    with tarfile.open(path, "w:bz2") as tf:
        tf.add(fixture_dir, arcname="r4.2")
    release = Release(path)
    assert release.exists("logon.csv")
    assert release.list_dir("LDAP")


def test_a_missing_table_is_reported_not_guessed(tmp_path):
    from mint.sources import Release

    (tmp_path / "logon.csv").write_text("id,date,user,pc,activity\n")
    release = Release(tmp_path)
    assert release.exists("logon.csv")
    assert not release.exists("http.csv")


def test_vectorised_tokens_match_the_row_definition():
    """The fast path and the readable definition must agree exactly.

    ``token_for`` is the specification; ``tokens_for_frame`` is what actually
    runs, because a per-row Python call over twenty-eight million web visits
    costs half an hour per pass. Two implementations of one rule is a standing
    invitation to drift, so the equivalence is asserted rather than assumed.
    """
    from mint.sessionise import token_for, tokens_for_frame

    cases = {
        "logon": pd.DataFrame({"activity": ["Logon", "Logoff", "logon"]}),
        "device": pd.DataFrame({"activity": ["Connect", "Disconnect"]}),
        "file": pd.DataFrame({"filename": [r"R:\\a.zip", r"C:\\b.docx", "/media/x"]}),
        "http": pd.DataFrame({"url": ["http://a", "http://b"]}),
        "email": pd.DataFrame({
            "from": ["a@co.invalid", "b@co.invalid", "c@co.invalid",
                     "z@co.invalid", "d@co.invalid"],
            "user": ["a", "b", "c", "a", "d"],
            "to": ["b@co.invalid", "out@else.invalid", "b@co.invalid",
                   "a@co.invalid", np.nan],
            "cc": [np.nan, np.nan, np.nan, np.nan, np.nan],
            "bcc": ["", "", "", "", ""],
            "attachments": [0, 0, 2, 0, 0],
        }),
    }
    for source, frame in cases.items():
        fast = list(tokens_for_frame(frame, source))
        slow = [token_for(source, row) for _, row in frame.iterrows()]
        assert fast == slow, f"{source}: {fast} != {slow}"


def test_a_resumed_run_produces_identical_artefacts(fixture_dir, cfg, tmp_path):
    """Checkpointing must be a pure optimisation, never a change of answer.

    Preparing the full release takes hours on machines that stop when you stop
    looking at them. Checkpoints make an interruption cheap — but only if
    resuming lands in exactly the same place a clean run would, which is what
    this asserts.
    """
    from mint.prepare import prepare

    cache = tmp_path / "cache"
    cold = prepare(fixture_dir, cfg, "hashing", synthetic=True, cache_dir=cache)
    assert (cache / "sessions.pkl").exists()
    assert (cache / "documents.pkl").exists()

    warm = prepare(fixture_dir, cfg, "hashing", synthetic=True, cache_dir=cache)

    assert len(cold) == len(warm)
    assert (cold.tokens == warm.tokens).all()
    assert (cold.content == warm.content).all()
    assert cold.n_labelled_malicious == warm.n_labelled_malicious


def test_a_corrupt_checkpoint_is_ignored_not_fatal(fixture_dir, cfg, tmp_path):
    from mint.prepare import prepare

    cache = tmp_path / "cache"
    cache.mkdir()
    (cache / "sessions.pkl").write_bytes(b"not a pickle")
    bundle = prepare(fixture_dir, cfg, "hashing", synthetic=True, cache_dir=cache)
    assert len(bundle) > 0


def test_only_this_releases_answer_files_are_read():
    """One archive holds every CERT release's answers. Read only ours.

    CERT reuses user identifiers between releases, so rows from r4.1 or r6
    join cleanly onto real r4.2 user-days and mark innocent people malicious.
    The only reason this was caught is that r5 and r6 write timestamps in a
    different format and the parser refused them; with a shared format the run
    would have completed and produced quietly wrong labels.
    """
    from mint.prepare import answers_for_release

    refs = [
        "answers/insiders.csv",
        "answers/r3.1-1.csv",
        "answers/r4.1-2.csv",
        "answers/r4.2-1/r4.2-1-AAM0658.csv",
        "answers/r4.2-2/r4.2-2-ABC0174.csv",
        "answers/r6.2-3.csv",
    ]
    kept = answers_for_release(refs, "r4.2")
    assert kept == ["answers/r4.2-1/r4.2-1-AAM0658.csv",
                    "answers/r4.2-2/r4.2-2-ABC0174.csv"]
    # r4.1 must not be swept in by a loose prefix match on "r4"
    assert not any("r4.1" in r for r in kept)
    # references that come out of an archive carry an "archive::member" prefix
    kept = answers_for_release(
        ["a.tar.bz2::answers/r4.2-1/x.csv", "a.tar.bz2::answers/r5.1-1.csv"],
        "r4.2")
    assert kept == ["a.tar.bz2::answers/r4.2-1/x.csv"]


def test_a_release_with_no_matching_answers_keeps_everything_and_warns(caplog):
    """The fixture's single answers.csv has no release tag in its name."""
    from mint.prepare import answers_for_release

    refs = ["answers/answers.csv"]
    with caplog.at_level("WARNING"):
        kept = answers_for_release(refs, "r4.2")
    assert kept == refs
    assert "not trustworthy" in caplog.text


def _fake_encoder(dim=8):
    """Deterministic encoder: a document's vector depends only on its text."""
    class E:
        name = "fake"

        def encode(self, texts):
            out = np.zeros((len(texts), dim), dtype=np.float32)
            for i, t in enumerate(texts):
                h = abs(hash(t)) % 9973
                for j in range(dim):
                    out[i, j] = ((h >> j) & 0xFF) / 255.0 + j * 0.01
            return out
    return E()


def test_streaming_encode_puts_every_document_in_its_own_slot():
    """Chunking must not shift documents between days or slots.

    The two-step path assigned slots with a running cursor per day. That is
    correct only while the whole corpus is in one array; a chunk boundary
    falling mid-day would restart the cursor and silently overwrite slot 0.
    """
    from mint.prepare import encode_and_reduce

    docs = [["a", "b", "c"], [], ["d"], ["e", "f"], ["g", "h", "i", "j"]]
    train = np.array([True, True, True, False, False])
    enc = _fake_encoder()

    whole, _ = encode_and_reduce(docs, enc, max_docs=3, dim=8, out_dim=8,
                                 train_mask=train, seed=0, chunk=10_000)
    # one document per chunk is the most hostile boundary available
    piece, _ = encode_and_reduce(docs, enc, max_docs=3, dim=8, out_dim=8,
                                 train_mask=train, seed=0, chunk=1)
    assert np.array_equal(whole, piece)

    # day 1 has no documents and must stay empty
    assert not whole[1].any()
    # day 4 is truncated to max_docs, not wrapped around
    assert whole[4].shape[0] == 3
    # the vector in slot 0 of day 0 is the encoding of "a", unprojected here
    assert np.allclose(whole[0, 0], enc.encode(["a"])[0])


def test_the_projection_is_fitted_only_on_training_documents():
    from mint.prepare import encode_and_reduce

    docs = [[f"train doc {i}"] * 2 for i in range(60)]
    docs += [[f"test doc {i}"] * 2 for i in range(60)]
    train = np.array([True] * 60 + [False] * 60)
    _, reduction = encode_and_reduce(docs, _fake_encoder(), max_docs=2, dim=8,
                                     out_dim=2, train_mask=train, seed=0)
    assert reduction["reduction"] == "pca"
    # 60 training days x 2 documents; nothing from the test window may be used
    assert reduction["fitted_on_documents"] <= 120


def test_the_streaming_path_costs_a_fraction_of_the_two_step_one():
    """The point of the refactor, asserted rather than assumed."""
    from mint.prepare import encode_and_reduce

    docs = [["x", "y", "z"] for _ in range(400)]
    train = np.ones(400, dtype=bool)
    out, _ = encode_and_reduce(docs, _fake_encoder(64), max_docs=3, dim=64,
                               out_dim=8, train_mask=train, seed=0)
    two_step_peak = 400 * 3 * 64 * 4          # what encode_documents allocated
    assert out.nbytes < two_step_peak / 4


def test_a_degenerate_peer_group_does_not_kill_the_run():
    """One unusable covariance should cost that group's structure, not the run.

    `numpy.linalg.pinv` raises "SVD did not converge" on a badly conditioned
    matrix, three frames from the cause and naming neither the group nor the
    rows. A diagonal precision is a weaker comparison class but a legitimate
    one, and far cheaper than losing an hour of training.
    """
    from mint.scoring import _shrunk_precision

    # identical rows: zero covariance in every direction
    flat = np.ones((40, 8), dtype=np.float32)
    p = _shrunk_precision(flat)
    assert p.shape == (8, 8)
    assert np.isfinite(p).all()

    # a single poisoned row must not take the other thirty-nine with it
    poisoned = np.random.default_rng(0).normal(size=(40, 8))
    poisoned[7] = np.nan
    p = _shrunk_precision(poisoned)
    assert np.isfinite(p).all()

    # and a group too small to estimate anything from still returns something
    p = _shrunk_precision(np.array([[np.inf] * 8], dtype=np.float64))
    assert np.array_equal(p, np.eye(8))


def test_scoring_refuses_embeddings_that_are_mostly_nan():
    """Diverged training must stop, not quietly produce a table of numbers."""
    from mint.pipeline import _check_embeddings

    good = np.random.default_rng(0).normal(size=(100, 8))
    _check_embeddings(good)  # no exception

    diverged = good.copy()
    diverged[:50] = np.nan
    with pytest.raises(ValueError, match="Training diverged"):
        _check_embeddings(diverged)

    # a handful of bad rows is a warning, not a stop
    a_few = good.copy()
    a_few[3] = np.inf
    _check_embeddings(a_few)


def test_a_day_with_no_documents_does_not_produce_nan():
    """The bug that cost forty-five minutes of scoring before it showed up.

    Cross-attention over an entirely masked memory is a softmax over a row of
    -inf. PyTorch returns NaN rather than raising. The NaN then flows through
    the day embedding into the covariance fit, where it surfaces as
    "SVD did not converge" from inside numpy — three modules and three
    quarters of an hour away from the day that had no email in it.

    Every simulated day in the fixture happens to have text, which is exactly
    why the smoke test never caught this.
    """
    import torch
    from mint.model import build_model

    cfg = {"d_model": 32, "n_heads": 2, "n_layers_behaviour": 1,
           "n_layers_fusion": 1, "dropout": 0.0,
           "hour_embedding_dim": 8, "context_dim": 16}
    model = build_model(cfg, content_dim=8,
                        context_cardinalities=(3, 4), n_context_numeric=2)
    model.eval()

    batch = 4
    tokens = torch.ones(batch, 8, dtype=torch.long)
    hours = torch.zeros(batch, 8, dtype=torch.long)
    flags = torch.zeros(batch, 8, 4)
    content = torch.randn(batch, 6, 8)
    content[1] = 0.0          # this person wrote and read nothing that day
    content[3] = 0.0
    cat = torch.zeros(batch, 2, dtype=torch.long)
    num = torch.zeros(batch, 2)

    with torch.no_grad():
        out = model(tokens, hours, flags, content, cat, num)

    for name in ("day", "z_behaviour", "z_content", "logits"):
        assert torch.isfinite(out[name]).all(), f"{name} contains NaN"
    # and the empty days must still get a usable embedding, not zeros
    assert torch.isfinite(out["day"][1]).all()


def test_the_scoring_pass_is_shared_across_normalisations(monkeypatch):
    """Three normalisations, one forward pass.

    The pass over every user-day takes forty-five minutes on the real release
    and does not depend on the normalisation — the reference population
    changes how embeddings are compared, not how they are produced. Running
    it per normalisation cost two and a quarter hours for one arm's worth of
    numbers, and made the comparison weaker: any difference could in
    principle have come from a different forward pass rather than from the
    reference.
    """
    from mint import pipeline

    calls = {"n": 0}
    real = pipeline.embed_and_score

    def counted(*args, **kwargs):
        calls["n"] += 1
        return real(*args, **kwargs)

    monkeypatch.setattr(pipeline, "embed_and_score", counted)
    assert calls["n"] == 0
    # embed_arm is the only place the pass is invoked from run_study
    import inspect
    source = inspect.getsource(pipeline.run_study)
    assert "embed_arm(" in source, "run_study must embed once per arm"
    assert source.count("embed_arm(") == 1
    signals_src = inspect.getsource(pipeline.compute_signals)
    assert "raw=None" in inspect.signature(pipeline.compute_signals).__str__() \
        or "raw" in inspect.signature(pipeline.compute_signals).parameters


def test_mapping_a_categorical_column_survives_a_missing_key():
    """The memory optimisation quietly made four ordinary lines version-fragile.

    Every `user`, `pc`, `source` and `token` column is categorical, because
    that is what made thirty million rows fit in memory. `Series.map` on a
    categorical returns a categorical, and pandas 3 refuses a `fillna` value
    that is not already one of its categories — where pandas 2 quietly added
    it. So code that had been fine for the whole project raised TypeError on a
    different machine, an hour into a run, on the machine we had moved to
    precisely because the first one kept dying.

    This pins the behaviour directly, so it cannot depend on which pandas the
    reviewer happens to have.
    """
    import pandas as pd
    from mint.sessionise import map_and_fill

    users = pd.Series(["AAM0658", "BDV0168", "CAH0936"], dtype="category")
    own = {"AAM0658": "PC-1", "BDV0168": "PC-2"}      # the third has no machine

    out = map_and_fill(users, own, "")
    assert out.tolist() == ["PC-1", "PC-2", ""]

    # numeric maps must stay usable as numbers afterwards
    sources = pd.Series(["logon", "http", "unknown"], dtype="category")
    budget = pd.to_numeric(map_and_fill(sources, {"logon": 12, "http": 32}, 32))
    assert budget.tolist() == [12, 32, 32]
    assert (budget.to_numpy() > 0).all()

    # a plain object column must behave identically
    plain = pd.Series(["AAM0658", "BDV0168", "CAH0936"])
    assert map_and_fill(plain, own, "").tolist() == out.tolist()


def test_dates_have_one_resolution_everywhere():
    """Mismatched datetime units join badly, and one way of doing it is silent.

    pandas 3 infers a resolution from the input, so `day` from parsed event
    timestamps and `snapshot` from a filename like "2010-07" can end up as
    datetime64[ns] and datetime64[s]. merge_asof raises on that. A plain merge
    on ["user", "day"] does something worse: it matches nothing, attaches zero
    labels, and reports zero malicious user-days as though the answer files
    were missing.

    Both were live on Colab and neither on the machine this was written on,
    which is why the resolution is now pinned at the single point every date
    in the project passes through.
    """
    import pandas as pd
    from mint.prepare import resolve_context
    from mint.schema import CONTEXT_CATEGORICAL
    from mint.sessionise import parse_dates

    stamps = pd.Series(["01/04/2010 06:45:43", "02/11/2010 19:02:11"])
    parsed = parse_dates(stamps)
    assert parsed.dtype == "datetime64[ns]", "the choke point must pin the unit"

    index = pd.DataFrame({"user": ["AAA0001", "BBB0002"],
                          "day": parsed.dt.normalize()})

    # built the way load_ldap builds it, from a filename, at second resolution
    ldap = pd.DataFrame({
        "user": ["AAA0001", "BBB0002"],
        "snapshot": pd.Series([pd.Timestamp("2010-01-01")] * 2
                              ).astype("datetime64[s]"),
        "supervisor": ["Boss A", "Boss B"],
    })
    for col in CONTEXT_CATEGORICAL:
        ldap[col] = ["one", "two"]

    psych = pd.DataFrame({"user": ["AAA0001", "BBB0002"],
                          "O": [1, 2], "C": [1, 2], "E": [1, 2],
                          "A": [1, 2], "N": [1, 2]})

    context, vocab = resolve_context(index, ldap, psych)
    assert len(context) == 2
    # both rows found their snapshot rather than falling through as unknown
    assert context[CONTEXT_CATEGORICAL[0]].notna().all()


def test_training_resumes_from_its_checkpoint(tmp_path, cfg, bundle):
    """Nine hours of training with nothing on disk is not a design.

    Twelve epochs take about nine hours on a CPU; a free hosted notebook is
    reclaimed at twelve. Losing the run at epoch ten costs a day, and it did.
    The checkpoint has to carry the optimiser and scheduler as well as the
    weights — resuming with a fresh optimiser restarts the momentum and the
    learning-rate schedule, which is not the same run continued, it is a
    different run wearing the same weights.
    """
    import torch
    from mint.training import train

    short = dict(cfg.training)
    short["epochs"] = 1
    ckpt = tmp_path / "training.pt"

    _, first = train(bundle, cfg.model, short, cfg.seed, checkpoint=ckpt)
    assert ckpt.exists(), "no checkpoint was written"
    assert len(first.history) == 1

    state = torch.load(ckpt, map_location="cpu", weights_only=False)
    for key in ("model", "optimiser", "scheduler", "epoch", "best_loss",
                "history"):
        assert key in state, f"{key} missing — a resume would not be faithful"
    assert state["epoch"] == 0

    # a second call with more epochs continues rather than starting over
    longer = dict(short)
    longer["epochs"] = 2
    _, second = train(bundle, cfg.model, longer, cfg.seed, checkpoint=ckpt)
    assert [row["epoch"] for row in second.history] == [0, 1], (
        "resuming must extend the history, not replay epoch 0")


def test_an_unreadable_training_checkpoint_starts_over_rather_than_dying(
        tmp_path, cfg, bundle):
    from mint.training import train

    ckpt = tmp_path / "training.pt"
    ckpt.write_bytes(b"not a checkpoint")
    short = dict(cfg.training)
    short["epochs"] = 1
    _, report = train(bundle, cfg.model, short, cfg.seed, checkpoint=ckpt)
    assert len(report.history) == 1
