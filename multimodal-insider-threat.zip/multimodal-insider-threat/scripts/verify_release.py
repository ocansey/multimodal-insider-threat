#!/usr/bin/env python3
"""Check that a copy of r4.2 is actually r4.2, before spending hours on it.

CMU distribute this release through figshare, which returns 403 to datacenter
IP ranges — Colab and most hosted notebooks cannot download it at all. The
practical answer is somebody else's mirror, and a mirror is a stranger's
re-upload: it may be a subset, a cleaned version, a different release, or
missing the answer keys entirely.

None of those announce themselves. A pipeline handed a subset produces
plausible tables and a quietly wrong study, which is worse than one that
crashes. So this refuses to guess: it counts the rows and compares them
against the release as published.

    python scripts/verify_release.py --raw data/raw/r4.2

The counts below were measured on CMU's own r4.2 in this project's Codespace
run, and the ones that appear in the literature (854,859 logon events;
28,434,423 http events) match. A copy that reproduces all five exactly is the
real release. A copy that does not is not usable for a result, whatever else
is right about it.

Exit status is 0 only if every table matches and both LDAP and the answer keys
are present.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

#: rows per activity table in the published release, header excluded
EXPECTED_ROWS = {
    "logon.csv": 854_859,
    "device.csv": 405_380,
    "file.csv": 445_581,
    "email.csv": 2_629_979,
    "http.csv": 28_434_423,
}

#: r4.2 covers a thousand people over roughly seventeen months
EXPECTED_USERS = 1_000
EXPECTED_LDAP_SNAPSHOTS = 18


def find(root: Path, name: str) -> Path | None:
    """Mirrors nest things differently; look for the file anywhere below root."""
    direct = root / name
    if direct.exists():
        return direct
    matches = sorted(root.rglob(name))
    return matches[0] if matches else None


def count_rows(path: Path) -> int:
    """Row count that respects quoting.

    Counting newlines would be much faster and wrong: http.csv and email.csv
    carry free text containing embedded newlines inside quoted fields, so a
    line count overstates the rows by a wide and uneven margin. Reading one
    column in chunks parses the quoting properly and still only touches a
    fraction of the file.
    """
    total = 0
    for chunk in pd.read_csv(path, usecols=[0], chunksize=1_000_000,
                             low_memory=False):
        total += len(chunk)
    return total


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raw", required=True, type=Path,
                    help="directory holding the release, extracted")
    ap.add_argument("--quick", action="store_true",
                    help="check only that the files exist, skipping the counts")
    args = ap.parse_args()

    root = args.raw.expanduser().resolve()
    if not root.is_dir():
        raise SystemExit(f"{root} is not a directory")

    print(f"checking {root}\n")
    problems: list[str] = []

    for name, expected in EXPECTED_ROWS.items():
        path = find(root, name)
        if path is None:
            print(f"  {name:<14} MISSING")
            problems.append(f"{name} is not in this copy")
            continue
        size = path.stat().st_size / 1e9
        if args.quick:
            print(f"  {name:<14} present, {size:.1f} GB")
            continue
        print(f"  {name:<14} counting …", end="\r", flush=True)
        rows = count_rows(path)
        verdict = "ok" if rows == expected else "MISMATCH"
        print(f"  {name:<14} {rows:>12,} rows  ({size:5.1f} GB)  {verdict}"
              + " " * 10)
        if rows != expected:
            problems.append(
                f"{name} has {rows:,} rows; the published release has "
                f"{expected:,} ({rows - expected:+,})")

    ldap = sorted(root.rglob("LDAP/*.csv"))
    print(f"\n  LDAP           {len(ldap)} monthly snapshots")
    if not ldap:
        problems.append("no LDAP snapshots — the peer-relative method needs them")
    elif len(ldap) < EXPECTED_LDAP_SNAPSHOTS:
        problems.append(
            f"only {len(ldap)} LDAP snapshots; the release has "
            f"{EXPECTED_LDAP_SNAPSHOTS}. Context would be resolved against a "
            "stale org chart for part of the study period.")
    else:
        people = pd.read_csv(ldap[0])["user_id"].nunique()
        print(f"                 {people:,} people in the first snapshot")
        if people != EXPECTED_USERS:
            problems.append(
                f"{people:,} people in LDAP; r4.2 has {EXPECTED_USERS:,}")

    answers = sorted(root.rglob("r4.2-*/*.csv")) or sorted(root.rglob("answers*"))
    print(f"  answers        {len(answers)} files")
    if not answers:
        problems.append(
            "no answer keys. They ship separately as answers.tar.bz2 and are "
            "frequently left out of mirrors. Without them nothing can be "
            "evaluated — the model will train happily and mean nothing.")

    psych = find(root, "psychometric.csv")
    print(f"  psychometric   {'present' if psych else 'missing (optional)'}")

    print("\n" + "=" * 70)
    if problems:
        print("This copy is NOT the published release:\n")
        for p in problems:
            print(f"  - {p}")
        print("\nA result computed from it would not be comparable with the "
              "literature and should not be published as r4.2. Find another "
              "source, or download from CMU directly on a machine figshare "
              "will serve.")
        return 1
    print("This copy matches the published r4.2 in every table checked.")
    print("Row counts, LDAP snapshots and answer keys are all as expected.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
